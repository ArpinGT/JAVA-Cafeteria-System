package CMS;

import CMS.customer.Customer;
import CMS.manager.Manager;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Login {

    private JFrame frame;
    private JPanel outerPanel; // Outer panel
    private JPanel innerPanel; // Inner panel
    private JLabel label;
    private JLabel label1;
    private JTextField usernameField;
    private JPasswordField passwordField;
        
    public Login() {
        frame = new JFrame("System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // Set the frame to full screen without decorations
        label1 = new JLabel("APU Cafeteria Ordering System");
        label1.setHorizontalAlignment(SwingConstants.CENTER);
        label1.setFont(new Font("Helvetica Neue",Font.PLAIN,38));
        frame.add(label1,BorderLayout.NORTH);
        outerPanel = new JPanel();
        outerPanel.setBackground(new Color(255,255,255)); // Set deep blue background color

        innerPanel = new JPanel(new BorderLayout()); // Use BorderLayout for the inner panel
        innerPanel.setBackground(new Color(0, 68, 128)); // Set deep blue background color
        innerPanel.setPreferredSize(new Dimension(550, 450)); // Set size for the inner panel

        // Add a label at the top of the inner panel
        label = new JLabel("USER LOGIN");
        label.setHorizontalAlignment(JLabel.CENTER); // Center the text
        label.setForeground(Color.WHITE);
        label.setFont(new Font("Arial", Font.PLAIN, 28)); // Set font and size

        // Add the label to the NORTH position of BorderLayout
        innerPanel.add(label, BorderLayout.NORTH);

        // Create and add username and password fields
        usernameField = new JTextField(20);
        passwordField = new JPasswordField(20);
        usernameField.setForeground(Color.GRAY); // Set gray color for demo text

        usernameField.setText("Example@gmail.com"); // Set demo text
        passwordField.setForeground(Color.GRAY); // Set gray color for demo text
        passwordField.setEchoChar((char) 0); // Show characters in the password field
        passwordField.setText("Password characters[8-32]"); // Set demo text
        
        JPanel inputPanel = new JPanel(new GridBagLayout()); // Use GridBagLayout for center alignment

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(5, 10, 5, 10);

        gbc.gridy = 0;
        JLabel usernameLabel = new JLabel("Username");
        usernameLabel.setFont(usernameLabel.getFont().deriveFont(Font.PLAIN, 14)); // Set font for username label
        inputPanel.add(usernameLabel, gbc);
        gbc.gridy++;
        gbc.gridwidth = 2; // Increase gridwidth to span two columns
        inputPanel.add(usernameField, gbc);

        gbc.gridy++;
        gbc.anchor = GridBagConstraints.WEST; // Align label to the left
        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setFont(passwordLabel.getFont().deriveFont(Font.PLAIN, 14)); // Set font for password label
        inputPanel.add(passwordLabel, gbc);
        gbc.gridy++;
        gbc.gridwidth = 2; // Increase gridwidth to span two columns
        inputPanel.add(passwordField, gbc);

        gbc.gridy++;
        gbc.gridwidth = 2; // Increase gridwidth to span two columns
        gbc.fill = GridBagConstraints.HORIZONTAL;
        JButton loginButton = new JButton("Login");
        loginButton.setPreferredSize(new Dimension(15, 27)); // Replace width and height with your desired values
        gbc.insets = new Insets(20, 10, 5, 10); // Increase vertical gap
        inputPanel.add(loginButton, gbc);

        gbc.gridy++;
        gbc.gridwidth = 2; // Increase gridwidth to span two columns
        gbc.fill = GridBagConstraints.NONE;
        gbc.insets = new Insets(5, 10, 10, 10); // Reset insets for next component
        gbc.anchor = GridBagConstraints.CENTER; // Align label at center
        JLabel registerLabel = new JLabel("Sign Up", SwingConstants.CENTER);
        registerLabel.setFont(registerLabel.getFont().deriveFont(Font.PLAIN, 16)); // Set font for register label
        registerLabel.setForeground(Color.BLUE); // Change the text color
        registerLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // Change cursor to hand when hovering
        inputPanel.add(registerLabel, gbc);

        gbc.gridy++;
        JLabel forgotPasswordLabel = new JLabel("Forgot Password?", SwingConstants.CENTER);
        forgotPasswordLabel.setFont(forgotPasswordLabel.getFont().deriveFont(Font.PLAIN, 12)); // Set font for forgot password label
        forgotPasswordLabel.setForeground(Color.BLACK); // Change the text color
        forgotPasswordLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // Change cursor to hand when hovering
        inputPanel.add(forgotPasswordLabel, gbc);

        innerPanel.add(inputPanel, BorderLayout.CENTER); // Add inputPanel to the CENTER

        // You probably don't need to add innerPanel here, as it's already a part of the outerPanel
        outerPanel.setLayout(new GridBagLayout()); // Use GridBagLayout for the outer panel

        GridBagConstraints constraints = new GridBagConstraints();
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.insets = new Insets(50, 50, 50, 50); // Add some padding around the inner panel
        outerPanel.add(innerPanel, constraints);

        frame.add(outerPanel);
        frame.setSize(550, 550); // Adjusted size for better visualization
        frame.setVisible(true);
        frame.setLocationRelativeTo(null); // Center the JFrame on the screen
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
     
        // Focus listener for the username field
        usernameField.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                if (usernameField.getForeground() == Color.GRAY && usernameField.getText().equals("Example@gmail.com")) {
                    usernameField.setText("");
                    usernameField.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (usernameField.getText().isEmpty()) {
                    usernameField.setForeground(Color.GRAY);
                    usernameField.setText("Example@gmail.com");
                }
            }
        });

        // Focus listener for the password field
        passwordField.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                if (passwordField.getForeground() == Color.GRAY) {
                    char[] passwordChars = passwordField.getPassword();
                    String password = new String(passwordChars);
                    if (password.equals("Password characters[8-32]")) {
                        passwordField.setText("");
                        passwordField.setForeground(Color.BLACK);
                        passwordField.setEchoChar('\u2022');
                    }
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                char[] passwordChars = passwordField.getPassword();
                String password = new String(passwordChars);
                if (password.isEmpty()) {
                    passwordField.setForeground(Color.GRAY);
                    passwordField.setEchoChar((char) 0);
                    passwordField.setText("Password characters[8-32]");
                }
            }
        });

        
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = passwordField.getText();
                if (username.equals("Example@gmail.com") && password.equals("Password characters[8-32]")) {
                    JOptionPane.showMessageDialog(frame, "Enter username & password!");
                    return;
                }
                if (!username.equals("Example@gmail.com") && password.equals("Password characters[8-32]")) {
                    JOptionPane.showMessageDialog(frame, "Enter password!");
                    return;
                }
                
                if (validateUserData(username, password)) {
                    performLogin();
                }
            }
        });
        
        registerLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                RegisterGUI registerPanel = new RegisterGUI();
                registerPanel.setPreferredSize(new Dimension(550, 600)); // Set size for the register panel
                outerPanel.removeAll();
                outerPanel.add(registerPanel, gbc);
                outerPanel.revalidate();
                outerPanel.repaint();
            }
        });
        
    }

    
    private void performLogin() {
        String username = usernameField.getText();
        char[] passwordChars = passwordField.getPassword();
        String password = new String(passwordChars);

        // Read the user credentials from the text file
        boolean isAdmin = false;
        boolean isLoginSuccessful = false;
        boolean isUserFound = false;
        boolean isPasswordCorrect = false; // Add this flag

        try (BufferedReader reader = new BufferedReader(new FileReader("User.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] credentials = line.split(",");
                if (credentials.length == 6 && credentials[1].equals(username)) {
                    isUserFound = true;
                    isAdmin = username.equals("admin@gmail.com");
                    if (credentials[2].equals(password)) {
                        isPasswordCorrect = true;
                        isLoginSuccessful = true;
                        break;
                    }
                }
            }

            if (isUserFound) {
                if (!isPasswordCorrect) {
                    JOptionPane.showMessageDialog(frame, "Incorrect password!");
                    passwordField.setText("");
                }
            } else {
                JOptionPane.showMessageDialog(frame, "Invalid username & password!"); // No matching user
                clearFields();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (isLoginSuccessful) {
            if (isAdmin) {
                // Open admin window
                new Manager();
            } else {
                // Open user window
                SwingUtilities.invokeLater(() -> {
                    new Customer().setVisible(true);
                });
            }
            // Close the login window after successful login
            frame.dispose();
        }
    }

    private void clearFields() {
        usernameField.setText("");
        passwordField.setText("");
    }
    private boolean validateUserData(String username, String password) {
        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Enter username & password!");
            return false; // Data is not valid
        }
        if (!username.matches("^[a-zA-Z0-9_@.]+$")) {
            JOptionPane.showMessageDialog(frame, "Invalid username format!");
            return false; // Data is not valid
        }

        if (!password.matches("^[a-zA-Z0-9!@#$%^&*()_+\\-=\\[\\]{};':\",./<>?\\\\|]{8,32}$")) {
            JOptionPane.showMessageDialog(frame, "Invalid password format!");
            return false; // Data is not valid
        }
        return true; // Data is valid
    }

    
   
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Login();
            }
        });
    }
}
