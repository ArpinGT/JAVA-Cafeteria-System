package CMS;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class RegisterGUI extends JPanel {

    private JLabel label;
    private JTextField nameField;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JTextField addressField;

    private JTextField genderField;
    private JTextField dobField;
    private JPanel inputPanel;
    private JCheckBox maleCheckBox;
    private JCheckBox femaleCheckBox;
    private JCheckBox otherCheckBox;


    public RegisterGUI() {
        setLayout(new BorderLayout()); // Use BorderLayout for the main panel
        setBackground(new Color(0, 68, 128)); // Set deep blue background color

        // Add a label at the top of the inner panel
        label = new JLabel("USER REGISTRATION");
        label.setHorizontalAlignment(JLabel.CENTER); // Center the text
        label.setForeground(Color.WHITE);
        label.setFont(new Font("Arial", Font.PLAIN, 28)); // Set font and size
        add(label, BorderLayout.NORTH);

        // Create and add username and password fields
        nameField = new JTextField(20);
        usernameField = new JTextField(20);
        passwordField = new JPasswordField(20);
        addressField = new JTextField(20);
        genderField = new JTextField(20);
        dobField = new JTextField(20);
        
        inputPanel = new JPanel(new GridBagLayout()); // Use GridBagLayout for center alignment

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(5, 10, 5, 10);
        
        gbc.gridy = 0;
        JLabel nameLabel = new JLabel("Full Name");
        nameLabel.setFont(nameLabel.getFont().deriveFont(Font.PLAIN, 14)); // Set font for username label
        inputPanel.add(nameLabel, gbc);
        gbc.gridy++;
        gbc.gridwidth = 2; // Increase gridwidth to span two columns
        inputPanel.add(nameField, gbc);

        gbc.gridy++;
        gbc.anchor = GridBagConstraints.WEST; // Align label to the left
        JLabel usernameLabel = new JLabel("Username");
        usernameLabel.setFont(usernameLabel.getFont().deriveFont(Font.PLAIN, 14)); // Set font for username label
        inputPanel.add(usernameLabel, gbc);
        gbc.gridy++;
        gbc.gridwidth = 2; // Increase gridwidth to span two columns
        inputPanel.add(usernameField, gbc);

        gbc.gridy++;
        gbc.anchor = GridBagConstraints.WEST; // Align label to the left
        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setFont(passwordLabel.getFont().deriveFont(Font.PLAIN, 14)); // Set font for password label
        inputPanel.add(passwordLabel, gbc);
        gbc.gridy++;
        gbc.gridwidth = 2; // Increase gridwidth to span two columns
        inputPanel.add(passwordField, gbc);
        
        gbc.gridy++;
        gbc.anchor = GridBagConstraints.WEST; // Align label to the left
        JLabel addressLabel = new JLabel("Address");
        addressLabel.setFont(addressLabel.getFont().deriveFont(Font.PLAIN, 14)); // Set font for password label
        inputPanel.add(addressLabel, gbc);
        gbc.gridy++;
        gbc.gridwidth = 2; // Increase gridwidth to span two columns
        inputPanel.add(addressField, gbc);
        
        // Add gender label
        gbc.gridy++;
        gbc.anchor = GridBagConstraints.WEST; // Align label to the left
        JLabel genderLabel = new JLabel("Gender");
        genderLabel.setFont(genderLabel.getFont().deriveFont(Font.PLAIN, 14)); // Set font for gender label
        inputPanel.add(genderLabel, gbc);
        gbc.gridy++;
        
        // Create a new constraint for checkboxes
        GridBagConstraints checkboxesGbc = new GridBagConstraints();
        checkboxesGbc.anchor = GridBagConstraints.WEST;
        checkboxesGbc.gridx = 1; // Start checkboxes from the second column
        checkboxesGbc.gridwidth = 2; // Adjust the width to span multiple columns


        maleCheckBox = new JCheckBox("Male");
        inputPanel.add(maleCheckBox, checkboxesGbc);
        gbc.gridy++;

        femaleCheckBox = new JCheckBox("Female");
        inputPanel.add(femaleCheckBox, checkboxesGbc);
        gbc.gridy++;

        otherCheckBox = new JCheckBox("Other");
        inputPanel.add(otherCheckBox, checkboxesGbc);


        gbc.gridy++;
        gbc.anchor = GridBagConstraints.WEST; // Align label to the left
        JLabel dobLabel = new JLabel("Date Of Birth (DOB)");
        dobLabel.setFont(dobLabel.getFont().deriveFont(Font.PLAIN, 14)); // Set font for password label
        inputPanel.add(dobLabel, gbc);
        gbc.gridy++;
        gbc.gridwidth = 2; // Increase gridwidth to span two columns
        inputPanel.add(dobField, gbc);

        gbc.gridy++;
        gbc.gridwidth = 2; // Increase gridwidth to span two columns
        gbc.fill = GridBagConstraints.HORIZONTAL;
        JButton registerButton = new JButton("Sign Up");
        registerButton.setPreferredSize(new Dimension(15, 27)); // Replace width and height with your desired values
        gbc.insets = new Insets(20, 10, 5, 10); // Increase vertical gap
        inputPanel.add(registerButton, gbc);
        
        gbc.gridy++;
        JLabel forgotPasswordLabel = new JLabel("Already have an account?", SwingConstants.CENTER);
        forgotPasswordLabel.setFont(forgotPasswordLabel.getFont().deriveFont(Font.PLAIN, 12)); // Set font for forgot password label
        forgotPasswordLabel.setForeground(Color.BLACK); // Change the text color
        forgotPasswordLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // Change cursor to hand when hovering
        inputPanel.add(forgotPasswordLabel, gbc);
        
        gbc.gridy++;
        gbc.gridwidth = 2; // Increase gridwidth to span two columns
        gbc.fill = GridBagConstraints.NONE;
        gbc.insets = new Insets(5, 10, 10, 10); // Reset insets for next component
        gbc.anchor = GridBagConstraints.CENTER; // Align label at center
        JLabel loginLabel = new JLabel("LOGIN", SwingConstants.CENTER);
        loginLabel.setFont(loginLabel.getFont().deriveFont(Font.PLAIN, 16)); // Set font for register label
        loginLabel.setForeground(Color.BLUE); // Change the text color
        loginLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // Change cursor to hand when hovering
        inputPanel.add(loginLabel, gbc);

        add(inputPanel, BorderLayout.CENTER); // Add inputPanel to the CENTER

        // Show the window
        setVisible(true);
        setInstructionText(nameField, "John Doe");
        setInstructionText(usernameField, "Example@gmail.com");
        setInstructionText(addressField, "Enter address");
        setInstructionText(dobField, "YYYY-MM-DD");
        
        passwordField.setForeground(Color.GRAY); // Set gray color for demo text
        passwordField.setEchoChar((char) 0); // Show characters in the password field
        passwordField.setText("Password characters[8-32]"); // Set demo text
        
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                String username = usernameField.getText();
                String password = passwordField.getText();
                String address = addressField.getText();
                String gender = genderField.getText();
                String dob = dobField.getText();

                if (name.equals("John Doe") && username.equals("Example@gmail.com") && password.equals("Password characters[8-32]") && address.equals("Enter address") && dob.equals("YYYY-MM-DD")) {
                    JOptionPane.showMessageDialog(RegisterGUI.this, "Fill required fields!");
                    return;
                }
                 // Perform data validation
                if (validateUserData(name, username, password, address, gender, dob)) {
                    Data();
                    JOptionPane.showMessageDialog(RegisterGUI.this, "Register Successful!");
                    clearFields();
                }
                
            }
        });
        
     
        
        loginLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                new Login();
                // Find the parent JFrame and close it
                Window parentWindow = SwingUtilities.windowForComponent(RegisterGUI.this);
                if (parentWindow instanceof JFrame) {
                    ((JFrame) parentWindow).dispose(); // Close the JFrame
                }
                
            }
        });
        // Add action listeners to the checkboxes to allow selecting only one at a time
        maleCheckBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                femaleCheckBox.setSelected(false);
                otherCheckBox.setSelected(false);
            }
        });

        femaleCheckBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                maleCheckBox.setSelected(false);
                otherCheckBox.setSelected(false);
            }
        });

        otherCheckBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                maleCheckBox.setSelected(false);
                femaleCheckBox.setSelected(false);
            }
        });
        // Focus listener for the password field
        passwordField.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                if (passwordField.getForeground() == Color.GRAY) {
                    char[] passwordChars = passwordField.getPassword();
                    String password = new String(passwordChars);
                    if (password.equals("Password characters[8-32]")) {
                        passwordField.setText("");
                        passwordField.setForeground(Color.BLACK);
                        passwordField.setEchoChar('\u2022');
                    }
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                char[] passwordChars = passwordField.getPassword();
                String password = new String(passwordChars);
                if (password.isEmpty()) {
                    passwordField.setForeground(Color.GRAY);
                    passwordField.setEchoChar((char) 0);
                    passwordField.setText("Password characters[8-32]");
                }
            }
        });
        
    }
    
    private void setInstructionText(JTextField textField, String instructionText) {
        textField.setForeground(Color.GRAY); // Set gray color for instruction text
        textField.setText(instructionText);

        textField.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                if (textField.getForeground() == Color.GRAY && textField.getText().equals(instructionText)) {
                    textField.setText("");
                    textField.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (textField.getText().isEmpty()) {
                    textField.setForeground(Color.GRAY);
                    textField.setText(instructionText);
                }
            }
        });
    }

    private void Data() {
        String name = nameField.getText();
        String username = usernameField.getText();
        String password = passwordField.getText();
        String address = addressField.getText();
        String dob = dobField.getText();

        String gender = ""; // Initialize gender as an empty string

        // Determine the selected gender
        if (maleCheckBox.isSelected()) {
            gender = "Male";
        } else if (femaleCheckBox.isSelected()) {
            gender = "Female";
        } else if (otherCheckBox.isSelected()) {
            gender = "Other";
        }

        // Validate data if necessary

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("User.txt", true))) {
            String line = name + "," + username + "," + password + "," + address + "," + gender + "," + dob + "\n";
            writer.write(line);
        } 
        catch (IOException e) {
            e.printStackTrace();
            // Handle file writing error if needed
        }
    }
    private boolean validateUserData(String name, String username, String password, String address, String gender, String dob) {
        if (name.isEmpty() || username.isEmpty() || password.isEmpty() || address.isEmpty()) {
            JOptionPane.showMessageDialog(RegisterGUI.this, "Fill required fields!");
            return false; // Data is not valid
        }

        // Validate name, username, password, and address
        if (!name.matches("^[a-zA-Z ]+$")) {
            JOptionPane.showMessageDialog(RegisterGUI.this, "Invalid name format!");
            return false; // Data is not valid
        }

        if (!username.matches("^[a-zA-Z0-9_@.]+$")) {
            JOptionPane.showMessageDialog(RegisterGUI.this, "Invalid username format!");
            return false; // Data is not valid
        }

        if (!password.matches("^[a-zA-Z0-9!@#$%^&*()_+\\-=\\[\\]{};':\",./<>?\\\\|]{8,32}$")) {
            JOptionPane.showMessageDialog(RegisterGUI.this, "Invalid password format!");
            return false; // Data is not valid
        }

        if (!address.matches("^[a-zA-Z0-9_\\-,.@ ]+$")) {
            JOptionPane.showMessageDialog(RegisterGUI.this, "Invalid address format!");
            return false; // Data is not valid
        }

        // Validate gender selection
        if (!maleCheckBox.isSelected() && !femaleCheckBox.isSelected() && !otherCheckBox.isSelected()) {
            JOptionPane.showMessageDialog(RegisterGUI.this, "Select a gender");
            return false; // Data is not valid
        }

        // Validate DOB format
        if (!dob.matches("\\d{4}-\\d{2}-\\d{2}")) {
            JOptionPane.showMessageDialog(RegisterGUI.this, "Invalid DOB format!");
            return false; // Data is not valid
        }

        // Perform additional validation if needed
        // For example, you can use regular expressions or other checks to validate the format of email, phone, etc.

        return true; // Data is valid
    }

    
    private void clearFields() {
        nameField.setText("");
        usernameField.setText("");
        passwordField.setText("");
        addressField.setText("");
        genderField.setText("");
        dobField.setText("");
        
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Registration Form");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            // Create a Dimension object with the desired width and height
            Dimension size = new Dimension(550, 600);
            // Set the size of the frame using the Dimension object
            frame.setSize(size);
            frame.getContentPane().add(new RegisterGUI());
            frame.setVisible(true);
        });
    }
}
