package CMS.customer;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Billreceipt extends JPanel {
    
    private JTextArea billTextArea;
    private ArrayList<Double> sectionPrices;
    
    public Billreceipt() {
        // Set the layout for the Billreceipt panel
        setLayout(new BorderLayout());

        // Create and configure components for the Billreceipt panel
        JLabel label = new JLabel("Receipt");
        billTextArea = new JTextArea(10, 30);
        billTextArea.setEditable(false); // Make the text area read-only
        JButton totalButton = new JButton("Total");
        JButton payButton = new JButton("PayReceipt");

        // Add the label to the top (North) of the panel
        add(label, BorderLayout.NORTH);

        // Create a panel for the buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(totalButton);
        buttonPanel.add(payButton);

        // Add the text area and button panel to the center (Center) of the panel
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BorderLayout());
        centerPanel.add(billTextArea, BorderLayout.CENTER);
        centerPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(centerPanel, BorderLayout.CENTER);

        sectionPrices = new ArrayList<>();

        // Attach action listeners to the buttons
        totalButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double totalBill = calculateTotalBill();
                showgrandtotal(totalBill);
                // Perform the action you want when the "Total" button is clicked
                JOptionPane.showMessageDialog(Billreceipt.this, "Total Bill is calculated!");
            }
        });

        payButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String billContent = billTextArea.getText();
                if (billContent != null && !billContent.trim().isEmpty()) {
                    saveReceiptToFile(billContent); // Save receipt to the file
                    JOptionPane.showMessageDialog(Billreceipt.this, "Receipt printed & will be there soon!");
                } else {
                    JOptionPane.showMessageDialog(Billreceipt.this, "Please total bill first!");
                }
            }
        });
    }

    private void saveReceiptToFile(String content) {
        try {
            File file = new File("ReceivedPayment.txt");
            FileWriter fileWriter = new FileWriter(file);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
            bufferedWriter.write(content);
            bufferedWriter.close();
        } 
        catch (IOException ex) {
            JOptionPane.showMessageDialog(Billreceipt.this, "Error saving receipt to file.");
            ex.printStackTrace();
        }
    }
    
    
    private double calculateTotalBill() {
        double totalAmount = 0.0;
        try {
            File file = new File("Order.txt");
            if (file.exists() && file.isFile() && file.length() > 0) {
                FileReader fileReader = new FileReader(file);
                BufferedReader bufferedReader = new BufferedReader(fileReader);

                String line;
                boolean isInSection = false;
                sectionPrices.clear(); // Clear the section prices before calculating again
                while ((line = bufferedReader.readLine()) != null) {
                    if (line.startsWith("--------------------------------------------------")) {
                        if (isInSection) {
                            // End of section, calculate total for this section
                            totalAmount += calculateSectionTotal(sectionPrices);
                            isInSection = false;
                        }
                    } 
                    else if (isInSection) {
                        String[] rowData = line.split(" - ");
                        if (rowData.length >= 2) {
                            double price = Double.parseDouble(rowData[1]);
                            sectionPrices.add(price);
                        }
                    } 
                    else if (line.toLowerCase().contains("total bill amount")) {
                        isInSection = true;
                    }
                }

                bufferedReader.close();
            } 
            else {
                JOptionPane.showMessageDialog(this, "No order data found.");
            }
        } 
        catch (IOException | NumberFormatException ex) {
            ex.printStackTrace();
        }
        return totalAmount;
    }

    private double calculateSectionTotal(ArrayList<Double> prices) {
        double sectionTotal = 0.0;
        for (Double price : prices) {
            sectionTotal += price;
        }
        return sectionTotal;
    }

    private void showgrandtotal(double totalBillAmount) {
        // Load data from the file and populate the text area
        StringBuilder textAreaContent = loadTextFromFile();

        // Set the content of the existing billTextArea
        billTextArea.setText(textAreaContent.append("===============================================\nGrand Total Amount: Rs ").append(totalBillAmount).toString());

        // Scroll to the top of the text area
        billTextArea.setCaretPosition(0);
    }

    private StringBuilder loadTextFromFile() {
        StringBuilder textContent = new StringBuilder();
        try {
            File file = new File("Order.txt");
            if (file.exists() && file.isFile()) {
                FileReader fileReader = new FileReader(file);
                BufferedReader bufferedReader = new BufferedReader(fileReader);

                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    textContent.append(line).append(System.lineSeparator());
                }

                bufferedReader.close();
            } else {
                textContent.append("No saved data found.");
            }
        }
        catch (IOException ex) {
            textContent.append("Error loading data from file.");
            ex.printStackTrace();
        }
        return textContent;
    }

}
