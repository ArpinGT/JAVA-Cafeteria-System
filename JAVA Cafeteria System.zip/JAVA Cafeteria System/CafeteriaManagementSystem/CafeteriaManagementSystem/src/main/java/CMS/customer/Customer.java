package CMS.customer;

import CMS.Login;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;


public class Customer extends JFrame implements ActionListener {
    JDesktopPane desktopPane;
    JPanel buttonPanel;
    JPanel displayPanel;
    JPanel billPanel;
    private JTable itemTable;
    private DefaultTableModel tableModel;
    private java.util.List<String[]> tableData = new ArrayList<>();

    
    private JLabel infoLabel; // To display initial information in the displayPanel

    private JTextArea billTextArea;


    public Customer() {
        
        // Create the main frame
        setTitle("Cafeteria Management System : Customer");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Create a panel for buttons at the bottom
        buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 40, 40)); // Center alignment, horizontal gap of 20, vertical gap of 10
        // Set the preferred size for the button panel
        int buttonPanelWidth = 600; // Set the desired width
        int buttonPanelHeight = 200; // Set the desired height
        buttonPanel.setPreferredSize(new Dimension(buttonPanelWidth, buttonPanelHeight));
        buttonPanel.setBackground(Color.LIGHT_GRAY); 
        
        
        // Create the displayPanel with a centered GridBagLayout
        displayPanel = new JPanel(new GridBagLayout());
        displayPanel.setBackground(Color.WHITE); // Set background color

        // Create constraints for center alignment
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.fill = GridBagConstraints.BOTH;
        
        // Add an empty panel to expand and center the infoLabel
        JPanel centeringPanel = new JPanel(new GridBagLayout());
        centeringPanel.add(new JPanel(), gbc);

        // Create the infoLabel with centered text
        infoLabel = new JLabel("Please select your choice");
        infoLabel.setHorizontalAlignment(JLabel.CENTER);
         // Set the font size and type for the infoLabel
        Font infoFont = new Font("Arial", Font.BOLD, 18); // Set your desired font properties
        infoLabel.setForeground(new Color(51, 51, 51)); // Dark gray
        infoLabel.setFont(infoFont);

        centeringPanel.add(infoLabel); // Add infoLabel to the centeringPanel

        // Add the centeringPanel to the displayPanel
        displayPanel.add(centeringPanel);
        desktopPane = new JDesktopPane();
        
        setLayout(new BorderLayout());
        add(desktopPane, BorderLayout.CENTER);

        
        billPanel = new JPanel();
        billPanel.setLayout(new FlowLayout());
        // Set the preferred size for the bill panel
        int billPanelWidth = 400; // Set the desired width
        int billPanelHeight = 400; // Set the desired height
        billPanel.setPreferredSize(new Dimension(billPanelWidth, billPanelHeight));
        billPanel.setBackground(Color.CYAN); // Set background color

        // Create a text label for the billPanel
        JLabel billLabel = new JLabel("Bill Information");
        billLabel.setHorizontalAlignment(JLabel.CENTER);
        billLabel.setFont(new Font("Arial", Font.BOLD, 18)); // Set the font for the label

        // Add the label to the top (North) of the billPanel
        billPanel.add(billLabel, BorderLayout.NORTH);

        // Create a text area for the billPanel
        billTextArea = new JTextArea(25, 30); // Initialize billTextArea with the desired rows and columns
        billTextArea.setEditable(false); // Make the text area read-only
        billPanel.add(billTextArea);
        
        // Create object of the buttons
        JButton view = new JButton("View Menu");
        JButton order = new JButton("Order Items");
        JButton reset = new JButton("Reset");
        JButton sum = new JButton("Bill Amount");
        JButton confirm = new JButton("Confirm Order");
        JButton pay = new JButton("Pay Bill");
        JButton feedback = new JButton("Give Feedback");
        JButton logout = new JButton("Logout"); // New button
        
        // Add action listeners to the buttons
        view.addActionListener(this);
        order.addActionListener(this);
        reset.addActionListener(this);
        sum.addActionListener(this);
        confirm.addActionListener(this);
        pay.addActionListener(this);
        feedback.addActionListener(this);
        logout.addActionListener(this);
    

        // Set action command names for the buttons
        view.setActionCommand("view");
        order.setActionCommand("order");
        reset.setActionCommand("reset");
        sum.setActionCommand("sum");  
        confirm.setActionCommand("confirm");
        pay.setActionCommand("pay");
        feedback.setActionCommand("feedback");
        logout.setActionCommand("logout");
        

        // Add buttons to the button panel
        buttonPanel.add(view);
        buttonPanel.add(order);
        buttonPanel.add(reset);
        buttonPanel.add(sum);
        buttonPanel.add(confirm);
        buttonPanel.add(pay);
        buttonPanel.add(feedback);
        buttonPanel.add(logout);

        // Add the button panel to the south (bottom)
        add(buttonPanel, BorderLayout.SOUTH);

        // Add display panel to the north
        // add(displayPanel, BorderLayout.WEST);

        // Add bill panel to the east
        add(billPanel, BorderLayout.EAST);

        // Add a "WELCOME" label to the top
        JLabel welcomeLabel = new JLabel("WELCOME TO CUSTOMER DASHBOARD!");
        welcomeLabel.setHorizontalAlignment(JLabel.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.PLAIN, 30));
        welcomeLabel.setForeground(new Color(255, 255, 255)); // Dark blue
        welcomeLabel.setBackground(new Color(0, 68, 128)); // Set the background color
        welcomeLabel.setOpaque(true); 
        add(welcomeLabel, BorderLayout.NORTH);
        
        // Add the displayPanel to the north with the welcome label
        add(displayPanel, BorderLayout.CENTER);
        
        // Set background colors for the panels
        buttonPanel.setBackground(new Color(51, 51, 102)); // Dark blue
        displayPanel.setBackground(new Color(245, 245, 245)); // Milky White
        billPanel.setBackground(new Color(200, 210, 210)); // Light blue

        // Customize button styles
        view.setBackground(new Color(0, 102, 204)); // Deep blue
        view.setForeground(Color.WHITE);
        order.setBackground(new Color(0, 102, 204)); // Deep blue
        order.setForeground(Color.WHITE);
        reset.setBackground(new Color(0, 102, 204)); // Deep blue
        reset.setForeground(Color.WHITE);
        sum.setBackground(new Color(0, 102, 204)); // Deep blue
        sum.setForeground(Color.WHITE);
        confirm.setBackground(new Color(0, 102, 204)); // Deep blue
        confirm.setForeground(Color.WHITE);
        pay.setBackground(new Color(0, 102, 204)); // Deep blue
        pay.setForeground(Color.WHITE);
        feedback.setBackground(new Color(0, 102, 204)); // Deep blue
        feedback.setForeground(Color.WHITE);
        logout.setBackground(new Color(153, 0, 0)); // Dark red
        logout.setForeground(Color.WHITE);
     
        // Create borders for the panels
        //Border panelBorder = BorderFactory.createLineBorder(Color.BLACK, 1);

        // Set the frame as visible
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("view")) {
            showItemsTable();
        }
        if (e.getActionCommand().equals("order")) {
            
            saveSelectedRowToFile();
            showItemsTextArea();
        }
        if (e.getActionCommand().equals("reset")) {
            clearSelectedRowDataFile();
            billTextArea.setText("");
        }
        if (e.getActionCommand().equals("sum")) {
            showtotalbill();
        }
        if (e.getActionCommand().equals("confirm")) {
            showtotalbill();
            saveBillData();
        }
        if (e.getActionCommand().equals("pay")) {
            // Open Billreceipt panel in the display panel
            Billreceipt billReceiptPanel = new Billreceipt();
            displayPanel.removeAll();
            displayPanel.setLayout(new FlowLayout(FlowLayout.CENTER)); // Center alignment
            displayPanel.add(billReceiptPanel);
            displayPanel.revalidate();
            displayPanel.repaint();
        }
        if (e.getActionCommand().equals("feedback")) {
            // Open Feedbackwriter panel in the display panel
            Feedbackwriter feedbackWriterPanel = new Feedbackwriter();
            displayPanel.removeAll();
            displayPanel.setLayout(new FlowLayout(FlowLayout.CENTER)); // Center alignment
            displayPanel.add(feedbackWriterPanel);
            displayPanel.revalidate();
            displayPanel.repaint();
        }
        if (e.getActionCommand().equals("logout")) {
            new Login();
            dispose();
        }
    }
    
    private void showItemsTable() {
        // clear table data list
        tableData.clear();
        // Load data from the file and populate the tableData list
        loadTableDataFromFile();

        // Create a table model with headers
        tableModel = new DefaultTableModel(new String[]{"Items", "Price(Rs)", "Quantity Available"}, 0);

        // Populate the table model with existing data from the list
        for (String[] rowData : tableData) {
            tableModel.addRow(rowData);
        }

        // Create the JTable with the table model
        itemTable = new JTable(tableModel);

         // Center align the price and quantity columns in the table
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        itemTable.getColumnModel().getColumn(1).setCellRenderer(centerRenderer); // Price column
        itemTable.getColumnModel().getColumn(2).setCellRenderer(centerRenderer); // Quantity column

        // Create a scroll pane to contain the table
        JScrollPane scrollPane = new JScrollPane(itemTable);

        // Clear the display panel and add the scroll pane
        displayPanel.removeAll();
        displayPanel.add(scrollPane);
        displayPanel.revalidate();
        displayPanel.repaint();
    }

    private void loadTableDataFromFile() {
        try {
            FileReader fileReader = new FileReader("MenuItems.txt");
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            String line;
            while ((line = bufferedReader.readLine()) != null) {
                String[] rowData = line.split("\\|");
                tableData.add(rowData);
            }

            bufferedReader.close();
        } 
        catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "An error occurred while reading the data!");
            ex.printStackTrace();
        }
    }
    
    private void saveSelectedRowToFile() {
        int selectedRow = itemTable.getSelectedRow();
        if (selectedRow != -1) {
            String[] rowData = tableData.get(selectedRow);

            // Format the selected row data as a string
            String formattedData = String.join("|", rowData);

            try {
                // Choose a file name or location for the saved data
                String fileName = "CheckoutOrder.txt";

                // Write the formatted data to the file
                FileWriter fileWriter = new FileWriter(fileName, true);
                PrintWriter printWriter = new PrintWriter(fileWriter);
                printWriter.println(formattedData);
                printWriter.close();
            } 
            catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "Error occured");
                ex.printStackTrace();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select item in menu table");
            
        }
    }

    private void showItemsTextArea() {
        int selectedRow = itemTable.getSelectedRow();
        if (selectedRow != -1) {
            // Load data from the file and populate the text area
            StringBuilder textAreaContent = loadTextFromFile();

            // Set the content of the existing billTextArea
            billTextArea.setText(textAreaContent.toString());

            // Scroll to the top of the text area
            billTextArea.setCaretPosition(0);
        } else {
            // If no row is selected, clear the text area
            billTextArea.setText("");
        }
    }



    private StringBuilder loadTextFromFile() {
        StringBuilder textContent = new StringBuilder();
        try {
            File file = new File("CheckoutOrder.txt");
            if (file.exists() && file.isFile()) {
                FileReader fileReader = new FileReader(file);
                BufferedReader bufferedReader = new BufferedReader(fileReader);

                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    String[] rowData = line.split("\\|");
                    if (rowData.length >= 2) {
                        textContent.append(rowData[0]).append(" - ").append(rowData[1]).append(System.lineSeparator());
                    } else {
                        textContent.append("Invalid data format: ").append(line).append(System.lineSeparator());
                    }
                }

                bufferedReader.close();
            } else {
                textContent.append("No saved data found.");
            }
        }
        catch (IOException ex) {
            textContent.append("Error loading data from file.");
            ex.printStackTrace();
        }
        return textContent;
    }

    private double calculateTotalBillAmount() {
        double totalAmount = 0.0;
        try {
            File file = new File("CheckoutOrder.txt");
            if (file.exists() && file.isFile() && file.length() > 0) {
                FileReader fileReader = new FileReader(file);
                BufferedReader bufferedReader = new BufferedReader(fileReader);

                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    String[] rowData = line.split("\\|");
                    if (rowData.length >= 2) {
                        double price = Double.parseDouble(rowData[1]);
                        totalAmount += price;
                    }
                }
            
                bufferedReader.close();
            }
            else {
                JOptionPane.showMessageDialog(this, "Please order items first!");
            }
        }
        catch (IOException | NumberFormatException ex) {
            ex.printStackTrace();
        }
        return totalAmount;
    }
    
    private void showtotalbill() {
        // Calculate the total bill amount
        double totalBillAmount = calculateTotalBillAmount();

        if (totalBillAmount > 0) {
            // Load data from the file and populate the text area
            StringBuilder textAreaContent = loadTextFromFile();

            // Set the content of the existing billTextArea
            textAreaContent.append("--------------------------------------------------\nTotal Bill Amount: Rs ").append(totalBillAmount);
            billTextArea.setText(textAreaContent.toString());

            // Scroll to the top of the text area
            billTextArea.setCaretPosition(0);
        }
    }


    private void saveBillData() {
        String billContent = billTextArea.getText();
        if (billContent != null && !billContent.trim().isEmpty()) { // Check if content is not null or empty
            try {
                FileWriter fileWriter = new FileWriter("Order.txt", true);
                PrintWriter printWriter = new PrintWriter(fileWriter);
                printWriter.println(billContent);
                printWriter.close();
                JOptionPane.showMessageDialog(this, "Your Order has been recorded!");

            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "Error saving bill data.");
                ex.printStackTrace();
            }
        } 
    }
    
    private void clearSelectedRowDataFile() {
        try {
            File file = new File("CheckoutOrder.txt");
            if (file.exists() && file.isFile()) {
                FileWriter fileWriter = new FileWriter(file);
                fileWriter.write(""); // Clear the file content
                fileWriter.close();

                JOptionPane.showMessageDialog(this, "Please add items!");
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error on ordering!");
            ex.printStackTrace();
        }
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Customer gui = new Customer();
            gui.setVisible(true);
        });
    }
}
