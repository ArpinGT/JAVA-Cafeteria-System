package CMS.customer;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Feedbackwriter extends JPanel {
    public Feedbackwriter() {
        // Set the layout for the Feedbackwriter panel
        setLayout(new BorderLayout());

        // Create and configure components for the Feedbackwriter panel
        JLabel label = new JLabel("Feedback");
        JTextArea feedbackTextArea = new JTextArea(10, 30);
        JButton submitButton = new JButton("Submit Feedback");
        JButton clearButton = new JButton("Clear");

        // Add the label to the top (North) of the panel
        add(label, BorderLayout.NORTH);

        // Create a panel for the buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(submitButton);
        buttonPanel.add(clearButton);

        // Add the text area and button panel to the center (Center) of the panel
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BorderLayout());
        centerPanel.add(feedbackTextArea, BorderLayout.CENTER);
        centerPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(centerPanel, BorderLayout.CENTER);
        
        // Attach action listeners to the buttons
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String feedback = feedbackTextArea.getText().trim(); // Trim whitespace
                if (feedback.isEmpty()) {
                    JOptionPane.showMessageDialog(Feedbackwriter.this, "Please enter feedback text.");
                } else {
                    try {
                        // Save the feedback to the "Userfeedback.txt" file
                        PrintWriter writer = new PrintWriter(new FileWriter("Userfeedback.txt", true)); // Append mode
                        writer.println("************");
                        writer.println(feedback);
                        writer.close();
                        JOptionPane.showMessageDialog(Feedbackwriter.this, "Thank you for your feedback! ");
                        feedbackTextArea.setText("");
                    } catch (IOException ex) {
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(Feedbackwriter.this, "An error occurred while saving the feedback.");
                    }
                }
            }
        });
            

        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                feedbackTextArea.setText("");
            }
        });
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Feedbackwriter Test");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.add(new Feedbackwriter());
            frame.pack();
            frame.setVisible(true);
        });
    }
}
