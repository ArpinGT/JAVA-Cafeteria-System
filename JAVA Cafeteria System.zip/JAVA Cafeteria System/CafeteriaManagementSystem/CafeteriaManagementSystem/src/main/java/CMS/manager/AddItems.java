package CMS.manager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class AddItems extends JPanel {
    private JTextField itemNameField;
    private JTextField priceField;
    private JTextField quantityField;
    private JButton addButton;
    private JButton clearButton;

    public AddItems() {
        // Set the layout for the AddItems panel
        setLayout(new BorderLayout());
        // Create and configure components for the label
        JLabel titleLabel = new JLabel("Add Item Details");
        titleLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        titleLabel.setHorizontalAlignment(JLabel.CENTER);
        titleLabel.setForeground(Color.BLACK);
        // Add the titleLabel to the top center of the panel
        add(titleLabel, BorderLayout.NORTH);

        
        // Create and configure components for the input panel
        JPanel inputPanel = new JPanel(new GridLayout(0, 1, 10, 10)); // Variable rows, 2 columns, horizontal and vertical gaps of 10
        
        // Item Name
        JLabel itemNameLabel = new JLabel("Item Name");
        itemNameField = new JTextField(15);
        inputPanel.add(itemNameLabel);
        inputPanel.add(itemNameField);

        // Price
        JLabel priceLabel = new JLabel("Price(Rs)");
        priceField = new JTextField(15);
        inputPanel.add(priceLabel);
        inputPanel.add(priceField);

        // Quantity
        JLabel quantityLabel = new JLabel("Quantity");
        quantityField = new JTextField(15);
        inputPanel.add(quantityLabel);
        inputPanel.add(quantityField);

        // Add the inputPanel to the top (North) of the panel
        add(inputPanel, BorderLayout.CENTER);

        // Create a panel for the buttons
        JPanel buttonPanel = new JPanel();
        addButton = new JButton("Add");
        clearButton = new JButton("Clear");
        buttonPanel.add(addButton);
        buttonPanel.add(clearButton);

        // Add the button panel to the bottom (South) of the panel
        add(buttonPanel, BorderLayout.SOUTH);

        // Attach action listeners to the buttons
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String itemName = itemNameField.getText().trim();
                String price = priceField.getText().trim();
                String quantity = quantityField.getText().trim();

                if (itemName.isEmpty() || price.isEmpty() || quantity.isEmpty()) {
                    JOptionPane.showMessageDialog(AddItems.this, "Please fill in all fields");
                } else {
                    try {
                        // Validate price and quantity as integers
                        int parsedPrice = Integer.parseInt(price);
                        int parsedQuantity = Integer.parseInt(quantity);

                        // Save the item information to the "MenuItems.txt" file
                        PrintWriter writer = new PrintWriter(new FileWriter("MenuItems.txt", true)); // Append mode
                        writer.println(itemName + "|" + parsedPrice + "|" + parsedQuantity);
                        writer.close();
                        JOptionPane.showMessageDialog(AddItems.this, "Item added successfully!");
                        clearFields();
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(AddItems.this, "Enter numerical values for price and quantity!");
                    } catch (IOException ex) {
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(AddItems.this, "An error occurred while adding item!");
                    }
                }
            }            
        });
    }

    private void clearFields() {
        itemNameField.setText("");
        priceField.setText("");
        quantityField.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Add Item Test");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.add(new AddItems());
            frame.pack();
            frame.setVisible(true);
        });
    }
}
