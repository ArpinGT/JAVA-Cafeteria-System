package CMS.manager;

import CMS.Login;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import java.util.List;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumnModel;



public class Manager extends JFrame implements ActionListener {
    JDesktopPane desktopPane;
    JPanel buttonPanel;
    JPanel displayPanel;
    JPanel billPanel;
    private JLabel infoLabel; // To display initial information in the displayPanel

    private JTable itemTable;
    private JTable userTable;
    private DefaultTableModel tableModel;
    private List<String[]> tableData = new ArrayList<>();
    private JTextArea billTextArea;

    private static final int FEEDBACK_FONT_SIZE = 14; // Set your desired font size

    private JTextField searchField;
    private String currentSearchTerm = ""; // Add this field
    private boolean isViewingSearchResults = false;

    
    public Manager() {
        
        // Create the main frame
        setTitle("Cafeteria Management System : Manager");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Create a panel for buttons at the bottom
        buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 30, 40)); // Center alignment, horizontal gap of 20, vertical gap of 10
        // Set the preferred size for the button panel
        int buttonPanelWidth = 600; // Set the desired width
        int buttonPanelHeight = 200; // Set the desired height
        buttonPanel.setPreferredSize(new Dimension(buttonPanelWidth, buttonPanelHeight));
        buttonPanel.setBackground(Color.LIGHT_GRAY); 
        searchField = new JTextField(22); // Adjust the size as needed
        String sampleText = "Enter search keyword";
        searchField.setText(sampleText); // Set the sample text initially
        searchField.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                if (searchField.getText().equals(sampleText)) {
                    searchField.setText("");
                    searchField.setForeground(Color.GRAY); // Set text color to black
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (searchField.getText().isEmpty()) {
                    searchField.setText(sampleText);
                    searchField.setForeground(Color.GRAY); // Set text color to gray
                }
            }
        });

        // Create the displayPanel with a centered GridBagLayout
        displayPanel = new JPanel(new GridBagLayout());
        displayPanel.setBackground(Color.WHITE); // Set background color

        // Create constraints for center alignment
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.fill = GridBagConstraints.BOTH;
        
        // Add an empty panel to expand and center the infoLabel
        JPanel centeringPanel = new JPanel(new GridBagLayout());
        centeringPanel.add(new JPanel(), gbc);

        // Create the infoLabel with centered text
        infoLabel = new JLabel("Please select your choice");
        infoLabel.setHorizontalAlignment(JLabel.CENTER);
         // Set the font size and type for the infoLabel
        Font infoFont = new Font("Arial", Font.BOLD, 18); // Set your desired font properties
        infoLabel.setForeground(new Color(51, 51, 51)); // Dark gray
        infoLabel.setFont(infoFont);

        centeringPanel.add(infoLabel); // Add infoLabel to the centeringPanel

        // Add the centeringPanel to the displayPanel
        displayPanel.add(centeringPanel);

        desktopPane = new JDesktopPane();
        setLayout(new BorderLayout());
        add(desktopPane, BorderLayout.CENTER);

        
        billPanel = new JPanel();
        billPanel.setLayout(new FlowLayout());
        // Set the preferred size for the bill panel
        int billPanelWidth = 400; // Set the desired width
        int billPanelHeight = 400; // Set the desired height
        billPanel.setPreferredSize(new Dimension(billPanelWidth, billPanelHeight));
        billPanel.setBackground(Color.CYAN); // Set background color

        // Create a text label for the billPanel
        JLabel billLabel = new JLabel("FEEDBACK SECTION");
        billLabel.setHorizontalAlignment(JLabel.CENTER);
        billLabel.setFont(new Font("Arial", Font.BOLD, 18)); // Set the font for the label

        // Add the label to the top (North) of the billPanel
        billPanel.add(billLabel, BorderLayout.NORTH);

        // Create a text area for the billPanel
        billTextArea = new JTextArea(25, 30);
        billTextArea.setEditable(true); // Make the text area read-only
        billTextArea.setLineWrap(true); // Enable line wrapping
        billPanel.add(billTextArea);
        
        // Create a JScrollPane for billTextArea
        JScrollPane billScrollPane = new JScrollPane(billTextArea);
        billScrollPane.setPreferredSize(new Dimension(400, 400)); // Set your desired dimensions

        billPanel.add(billScrollPane); // Add billScrollPane to the billPanel

        // Create object of the buttons
        JButton view = new JButton("View Items");
        JButton add = new JButton("Add Items");
        JButton remove = new JButton("Remove User");
        JButton delete = new JButton("Remove Item");
        JButton search = new JButton("Search User "); // New button
        JButton vieworder = new JButton("View Order"); // New button
        JButton regmanage = new JButton("View Registration");
        JButton payment = new JButton("Check Payment");
        JButton feedback = new JButton("View Feedback"); // New button
        JButton logout = new JButton("Logout"); // New button
        JButton update = new JButton("Update Feedback");
        
        // Add action listeners to the buttons
        view.addActionListener(this);
        add.addActionListener(this);
        remove.addActionListener(this);
        delete.addActionListener(this);
        search.addActionListener(this);
        vieworder.addActionListener(this);
        regmanage.addActionListener(this);
        payment.addActionListener(this);
        feedback.addActionListener(this);
        logout.addActionListener(this);
        update.addActionListener(this);

        // Set action command names for the buttons
        view.setActionCommand("view");
        add.setActionCommand("add");
        remove.setActionCommand("remove");
        delete.setActionCommand("delete");  
        search.setActionCommand("search");
        vieworder.setActionCommand("vieworder");
        regmanage.setActionCommand("regmanage");
        payment.setActionCommand("payment");
        feedback.setActionCommand("feedback");
        logout.setActionCommand("logout");
        update.setActionCommand("update");
        

        // Add buttons to the button panel
        buttonPanel.add(view);
        buttonPanel.add(add);
        buttonPanel.add(delete);
        buttonPanel.add(vieworder);
        buttonPanel.add(regmanage);
        buttonPanel.add(remove);
        buttonPanel.add(payment);
        buttonPanel.add(feedback);
        buttonPanel.add(logout);
        buttonPanel.add(searchField);
        buttonPanel.add(search);
        billPanel.add(update,BorderLayout.SOUTH);
        update.setBackground(new Color(32, 119, 180)); // Deep Blue
        update.setForeground(Color.WHITE);
        
        // Add the button panel to the south (bottom)
        add(buttonPanel, BorderLayout.SOUTH);

        // Add display panel to the north
        //add(displayPanel, BorderLayout.WEST);

        // Add bill panel to the east
        add(billPanel, BorderLayout.EAST);

        // Add a "WELCOME" label to the top
        JLabel welcomeLabel = new JLabel("LOGINED AS A MANAGER!");
        welcomeLabel.setHorizontalAlignment(JLabel.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.PLAIN, 30));
        welcomeLabel.setForeground(new Color(255, 255, 255)); 
        welcomeLabel.setBackground(new Color(0, 68, 128)); // Set the background color
        welcomeLabel.setOpaque(true); 
        add(welcomeLabel, BorderLayout.NORTH);
        
        // Add the displayPanel to the north with the welcome label
        add(displayPanel, BorderLayout.CENTER);

        // Set background colors for the panels
        buttonPanel.setBackground(new Color(45, 54, 90)); // Navy Blue
        displayPanel.setBackground(new Color(245, 245, 245)); // Milky White
        billPanel.setBackground(new Color(219, 223, 227)); // Platinum

        // Customize button styles
        view.setBackground(new Color(32, 119, 180)); // Deep Blue
        view.setForeground(Color.WHITE);
        add.setBackground(new Color(32, 119, 180)); // Deep Blue
        add.setForeground(Color.WHITE);
        remove.setBackground(new Color(32, 119, 180)); // Deep Blue
        remove.setForeground(Color.WHITE);
        delete.setBackground(new Color(32, 119, 180)); // Deep Blue
        delete.setForeground(Color.WHITE);
        search.setBackground(new Color(32, 119, 180)); // Deep Blue
        search.setForeground(Color.WHITE);
        vieworder.setBackground(new Color(32, 119, 180)); // Deep Blue
        vieworder.setForeground(Color.WHITE);
        regmanage.setBackground(new Color(32, 119, 180)); // Deep Blue
        regmanage.setForeground(Color.WHITE);
        payment.setBackground(new Color(32, 119, 180)); // Deep Blue
        payment.setForeground(Color.WHITE);
        feedback.setBackground(new Color(32, 119, 180)); // Deep Blue
        feedback.setForeground(Color.WHITE);
        logout.setBackground(new Color(169, 50, 38)); // Dark Red
        logout.setForeground(Color.WHITE);

        // Set the frame as visible
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        if (e.getActionCommand().equals("view")) {
            showItemsTable();
        }
        else if (e.getActionCommand().equals("add")) {
            // Open Feedbackwriter panel in the display panel
            AddItems additemsPanel  = new AddItems();
            displayPanel.removeAll();
            displayPanel.setLayout(new FlowLayout(FlowLayout.CENTER)); // Center alignment
            additemsPanel.setPreferredSize(new Dimension(300, 250)); // Set size for the register panel
            displayPanel.add(additemsPanel);
            displayPanel.revalidate();
            displayPanel.repaint();
        }
        else if (e.getActionCommand().equals("remove")) {
            int selectedRow = userTable.getSelectedRow();
            if (selectedRow != -1) {
                if (!isViewingSearchResults) {
                    tableModel.removeRow(selectedRow); // Remove from the table model
                    tableData.remove(selectedRow); // Remove from the data list
                    saveuserData(); // Save the updated data back to the file
                    JOptionPane.showMessageDialog(this, "User removed successfully!");
                } else {
                    JOptionPane.showMessageDialog(this, "Cannot remove users from search results.");
                }

                // If a search was performed, reapply the search after removing
                if (!currentSearchTerm.isEmpty()) {
                    searchUsers(currentSearchTerm);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Please select user row to delete.");
            }
        }

     
        
        else if (e.getActionCommand().equals("delete")) {
            // Get the selected row index from the JTable
            int selectedRow = itemTable.getSelectedRow();

            // Check if a row is selected
            if (selectedRow != -1) {
                // Get the data of the selected row
                String[] selectedData = tableData.get(selectedRow);

                // Remove the selected row data from the list
                tableData.remove(selectedRow);

                // Update the table model
                tableModel.removeRow(selectedRow);

                // Save the updated data back to the file
                saveTableDataToFile();

                JOptionPane.showMessageDialog(this, "Item deleted successfully!");
            } else {
                JOptionPane.showMessageDialog(this, "Please select item row to delete.");
            }
        }

        else if (e.getActionCommand().equals("search")) {
            String searchTerm = searchField.getText().trim().toLowerCase();
            if (!searchTerm.equals("Enter search keyword")) {
                if (!searchTerm.isEmpty()) {
                    searchUsers(searchTerm);
                    searchField.setText(""); // Clear the search field
                }
                else {
                JOptionPane.showMessageDialog(this, "Enter search keyword!");
                }
            
            }
        }

        else if (e.getActionCommand().equals("vieworder")) {
            // Open order panel in the display panel
            ViewOrder orderPanel = new ViewOrder();
            displayPanel.removeAll();
            displayPanel.setLayout(new FlowLayout(FlowLayout.CENTER)); // Center alignment
            displayPanel.add(orderPanel);
            displayPanel.revalidate();
            displayPanel.repaint();
        }
        else if (e.getActionCommand().equals("regmanage")) {
            showUsersTable();
        }
        else if (e.getActionCommand().equals("payment")) {
            // Open order panel in the display panel
            ViewPayment paymentPanel = new ViewPayment();
            displayPanel.removeAll();
            displayPanel.setLayout(new FlowLayout(FlowLayout.CENTER)); // Center alignment
            displayPanel.add(paymentPanel);
            displayPanel.revalidate();
            displayPanel.repaint();
        }
        
        else if (e.getActionCommand().equals("feedback")) {
            viewFeedback();
        }
        else if (e.getActionCommand().equals("logout")) {
            new Login();
            dispose();
        }
        else if (e.getActionCommand().equals("update")) {
            saveFeedback();
        }
    }

    

    private void viewFeedback() {
        try {
            FileReader fileReader = new FileReader("UserFeedback.txt");
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            StringBuilder feedback = new StringBuilder();
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                feedback.append(line).append("\n");
            }

            bufferedReader.close();

            if (feedback.length() > 0) {
                billTextArea.setText(feedback.toString()); // Set feedback to the billTextArea
                // Set font size for the billTextArea
                Font feedbackFont = new Font("Arial", Font.PLAIN, FEEDBACK_FONT_SIZE);
                billTextArea.setFont(feedbackFont);
                
            } else {
                billTextArea.setText("No feedback available.");
            }
        } catch (IOException ex) {
            billTextArea.setText("An error occurred while reading the feedback!");
            ex.printStackTrace();
        }
    }

    
    private void showItemsTable() {
        // clear table data list
        tableData.clear();
        // Load data from the file and populate the tableData list
        loadTableDataFromFile();

        // Create a table model with headers
        tableModel = new DefaultTableModel(new String[]{"Items", "Price(Rs)", "Quantity Available"}, 0);

        // Populate the table model with existing data from the list
        for (String[] rowData : tableData) {
            tableModel.addRow(rowData);
        }

        // Create the JTable with the table model
        itemTable = new JTable(tableModel);

         // Center align the price and quantity columns in the table
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        itemTable.getColumnModel().getColumn(1).setCellRenderer(centerRenderer); // Price column
        itemTable.getColumnModel().getColumn(2).setCellRenderer(centerRenderer); // Quantity column

        // Create a scroll pane to contain the table
        JScrollPane scrollPane = new JScrollPane(itemTable);

        // Clear the display panel and add the scroll pane
        displayPanel.removeAll();
        displayPanel.add(scrollPane);
        displayPanel.revalidate();
        displayPanel.repaint();
    }

    private void loadTableDataFromFile() {
        try {
            FileReader fileReader = new FileReader("MenuItems.txt");
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            String line;
            while ((line = bufferedReader.readLine()) != null) {
                String[] rowData = line.split("\\|");
                tableData.add(rowData);
            }

            bufferedReader.close();
        } 
        catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "An error occurred while reading the data!");
            ex.printStackTrace();
        }
    }

    private void loadUserData() {
        try {
            FileReader fileReader = new FileReader("User.txt");
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            String line;
            while ((line = bufferedReader.readLine()) != null) {
                String[] rowData = line.split(",");
                tableData.add(rowData);
            }

            bufferedReader.close();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "An error occurred while reading the data!");
            ex.printStackTrace();
        }
    }
    private void saveTableDataToFile() {
        try {
            PrintWriter writer = new PrintWriter(new FileWriter("MenuItems.txt"));
            for (String[] rowData : tableData) {
                writer.println(String.join("|", rowData)); // Use the same delimiter as when loading the data
            }
            writer.close();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "An error occurred while saving the data!");
            ex.printStackTrace();
        }
    }


    private void showUsersTable() {
        // clear table data list
        tableData.clear();
        // Load user data from the file and populate the tableData list
        loadUserData();

        // Create a table model with headers
        DefaultTableModel userModel = new DefaultTableModel(new String[]{"Name", "Email", "Password", "Address", "Gender", "DOB"}, 0);

        // Populate the table model with existing user data from the list
        for (String[] rowData : tableData) {
            userModel.addRow(rowData);
        }

        // Create the JTable with the userModel
        userTable = new JTable(userModel);

        // Center align columns in the table
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        userTable.getColumnModel().getColumn(1); // Email column
        userTable.getColumnModel().getColumn(2); // Password column
        userTable.getColumnModel().getColumn(4).setCellRenderer(centerRenderer); // Gender column
        userTable.getColumnModel().getColumn(5).setCellRenderer(centerRenderer); // DOB column

        int nameWidth = 150;
        int emailWidth = 200;
        int passwordWidth = 150;
        int addressWidth = 200;
        int genderWidth = 100;
        int dobWidth = 120;

        userTable.getColumnModel().getColumn(0).setPreferredWidth(nameWidth); // Name column
        userTable.getColumnModel().getColumn(1).setPreferredWidth(emailWidth); // Email column
        userTable.getColumnModel().getColumn(2).setPreferredWidth(passwordWidth); // Password column
        userTable.getColumnModel().getColumn(3).setPreferredWidth(addressWidth); // Address column
        userTable.getColumnModel().getColumn(4).setPreferredWidth(genderWidth); // Gender column
        userTable.getColumnModel().getColumn(5).setPreferredWidth(dobWidth); // DOB column
    
        // Create a scroll pane to contain the table
        JScrollPane scrollPane = new JScrollPane(userTable);

        // Clear the display panel and add the scroll pane
        displayPanel.removeAll();
        displayPanel.setLayout(new BorderLayout());
        displayPanel.add(scrollPane, BorderLayout.CENTER);
        displayPanel.revalidate();
        displayPanel.repaint();
    }

    private void saveuserData() {
        try {
            PrintWriter writer = new PrintWriter(new FileWriter("User.txt"));
            for (String[] rowData : tableData) {
                writer.println(String.join(",", rowData));
            }
            writer.close();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "An error occurred while saving the data!");
            ex.printStackTrace();
        }
    }
    private void searchUsers(String searchTerm) {
        isViewingSearchResults = true;
        currentSearchTerm = searchTerm;
        // clear table data list
        tableData.clear();
        // Load data from the file and populate the tableData list
        loadUserData();
        
        DefaultTableModel searchTableModel = new DefaultTableModel(new String[]{"Name", "Email", "Password", "Address", "Gender", "DOB"}, 0);
        boolean found = false;
        
        // Populate the table model with matching data from the list
        for (String[] rowData : tableData) {
            
            boolean matchFound = false;
            for (String field : rowData) {
                if (field.toLowerCase().contains(searchTerm)) {
                    matchFound = true;
                    searchTableModel.addRow(rowData);
                    break; // Only add once if any field matches
                }
            }
            if (matchFound){
                searchTableModel.addRow(rowData);
                found = true;
            }
        }
        
        if (!found) {
            JOptionPane.showMessageDialog(this, "No Users found.", "Search Results", JOptionPane.INFORMATION_MESSAGE);
        }

        // Create the JTable with the searchTableModel
        userTable = new JTable(searchTableModel);

        // ... (same as before) adjust preferred column widths, etc.

        // Create a scroll pane to contain the table
        JScrollPane scrollPane = new JScrollPane(userTable);

        // Clear the display panel and add the scroll pane
        displayPanel.removeAll();
        // Set the layout manager of the displayPanel to BorderLayout
        displayPanel.setLayout(new BorderLayout());

        // Add the scroll pane to the center of the display panel
        displayPanel.add(scrollPane, BorderLayout.CENTER);
        displayPanel.revalidate();
        displayPanel.repaint();
    }

    private void saveFeedback() {
        String feedback = billTextArea.getText();

        if (!feedback.isEmpty()) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter("Userfeedback.txt", false))) {
                writer.write(feedback);
                writer.newLine();
                writer.flush();
                JOptionPane.showMessageDialog(this, "Feedback updated successfully.");
                billTextArea.setText(""); // Clear the text area
            } catch (IOException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error while saving feedback.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please enter feedback before saving.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Manager gui = new Manager();
            gui.setVisible(true);
        });
    }
    
}
