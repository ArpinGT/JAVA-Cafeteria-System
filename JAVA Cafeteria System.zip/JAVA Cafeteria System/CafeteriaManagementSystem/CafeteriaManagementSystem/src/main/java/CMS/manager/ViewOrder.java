package CMS.manager;

import CMS.manager.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class ViewOrder extends JPanel {
    
    private JTextArea orderTextArea;
    
    
    public ViewOrder() {
        // Set the layout for the Billreceipt panel
        setLayout(new BorderLayout());

        // Create and configure components for the Billreceipt panel
        JLabel label = new JLabel("Orders");
        orderTextArea = new JTextArea(10, 30);
        orderTextArea.setEditable(true); // Make the text area read-only
        JButton readButton = new JButton("View");
        JButton saveButton = new JButton("Update");

        // Add the label to the top (North) of the panel
        add(label, BorderLayout.NORTH);

        // Create a panel for the buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(readButton);
        buttonPanel.add(saveButton);

        // Add the text area and button panel to the center (Center) of the panel
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BorderLayout());
        centerPanel.add(orderTextArea, BorderLayout.CENTER);
        centerPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(centerPanel, BorderLayout.CENTER);

        

        // Attach action listeners to the buttons
        readButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showorders();
            }
        });

        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String billContent = orderTextArea.getText();
                if (billContent != null && !billContent.trim().isEmpty()) {
                    saveOrdersToFile(billContent);  // Save orders to the file
                    orderTextArea.setText("");       // Clear the text area
                    // Inform the user about successful update
                    JOptionPane.showMessageDialog(ViewOrder.this, "Orders updated and saved!");
                } else {
                    JOptionPane.showMessageDialog(ViewOrder.this, "Please view orders first!");
                }
            }
        });
    }

    private void saveOrdersToFile(String content) {
        try {
            File file = new File("Order.txt");
            FileWriter fileWriter = new FileWriter(file, false);  // Overwrite the file
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
            bufferedWriter.write(content);
            bufferedWriter.close();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(ViewOrder.this, "Error saving orders to file.");
            ex.printStackTrace();
        }
    }

    private void showorders() {
        // Load data from the file and populate the text area
        StringBuilder textContent = loadorders();

        // Set the content of the existing billTextArea
        orderTextArea.setText(textContent.toString());

        // Scroll to the top of the text area
        orderTextArea.setCaretPosition(0);
    }

    private StringBuilder loadorders() {
        StringBuilder textContent = new StringBuilder();
        try {
            File file = new File("Order.txt");
            if (file.exists() && file.isFile()) {
                FileReader fileReader = new FileReader(file);
                BufferedReader bufferedReader = new BufferedReader(fileReader);

                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    textContent.append(line).append(System.lineSeparator());
                }

                bufferedReader.close();
            } else {
                textContent.append("No saved data found.");
            }
        }
        catch (IOException ex) {
            textContent.append("Error loading data from file.");
            ex.printStackTrace();
        }
        return textContent;
    }

}
