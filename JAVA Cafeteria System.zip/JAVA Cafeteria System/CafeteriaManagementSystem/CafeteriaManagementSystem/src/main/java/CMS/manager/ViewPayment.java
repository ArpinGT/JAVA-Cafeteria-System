package CMS.manager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ViewPayment extends JPanel {
    
    private JTextArea paymentTextArea;
    
    
    public ViewPayment() {
        // Set the layout for the Billreceipt panel
        setLayout(new BorderLayout());

        // Create and configure components for the Billreceipt panel
        JLabel label = new JLabel("Payments");
        paymentTextArea = new JTextArea(10, 30);
        paymentTextArea.setEditable(true); // Make the text area read-only
        JButton readButton = new JButton("View");
        JButton saveButton = new JButton("Update");

        // Add the label to the top (North) of the panel
        add(label, BorderLayout.NORTH);

        // Create a panel for the buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(readButton);
        buttonPanel.add(saveButton);

        // Add the text area and button panel to the center (Center) of the panel
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BorderLayout());
        centerPanel.add(paymentTextArea, BorderLayout.CENTER);
        centerPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(centerPanel, BorderLayout.CENTER);

        

        // Attach action listeners to the buttons
        readButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showpayments();
                // Perform the action you want when the "Total" button is clicked
                JOptionPane.showMessageDialog(ViewPayment.this, "Received payments!");
            }
        });

        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String paymentContent = paymentTextArea.getText();
                if (paymentContent != null && !paymentContent.trim().isEmpty()) {
                    savepaymentsToFile(paymentContent);  // Save orders to the file
                    paymentTextArea.setText("");       // Clear the text area
                    // Inform the user about successful update
                    JOptionPane.showMessageDialog(ViewPayment.this, "Payment history checked and saved!");
                } else {
                    JOptionPane.showMessageDialog(ViewPayment.this, "Please view payments first!");
                }
            }
        });
    }

    private void savepaymentsToFile(String content) {
        try {
            File file = new File("ReceivedPayment.txt");
            FileWriter fileWriter = new FileWriter(file, false);  // Overwrite the file
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
            bufferedWriter.write(content);
            bufferedWriter.close();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(ViewPayment.this, "Error saving orders to file.");
            ex.printStackTrace();
        }
    }

    private StringBuilder loadpayments() {
        StringBuilder textContent = new StringBuilder();
        try {
            File file = new File("ReceivedPayment.txt");
            if (file.exists() && file.isFile()) {
                FileReader fileReader = new FileReader(file);
                BufferedReader bufferedReader = new BufferedReader(fileReader);

                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    textContent.append(line).append(System.lineSeparator());
                }

                bufferedReader.close();
            } else {
                textContent.append("No saved data found.");
            }
        } catch (IOException ex) {
            textContent.append("Error loading data from file.");
            ex.printStackTrace();
        }
        return textContent;
    }



    private void showpayments() {
        // Load data from the file and populate the text area
        StringBuilder textContent = loadpayments();

        // Set the content of the existing paymentTextArea
        paymentTextArea.setText(textContent.toString());

        // Scroll to the top of the text area
        paymentTextArea.setCaretPosition(0);
    }


}
